create definer = root@`%` event e_test
  on schedule
    every '5' SECOND
      starts '2018-12-18 08:32:34'
  on completion preserve
  enable
do
  call update_order();

