create procedure update_order()
  BEGIN
    update order_info set oi_state = 3 where  oi_time < (select SUBDATE(now(),interval 5 minute)) and oi_state = 1;
END;

